An example game made in Ruby, used in my [Rapid Game Prototyping with Ruby](https://www.youtube.com/watch?v=Vo5OVEmSDtY) talk.
